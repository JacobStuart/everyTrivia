package com.example.demo;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DocController {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	TriviaMaster trivia;
	
	@RequestMapping("/home")
	public String home(Model model) {
		trivia = new TriviaMaster(this.jdbcTemplate);
		model.addAttribute("triviaAns", "" + trivia.getQuery());
		model.addAttribute("triviaQ", trivia.getQ());
		model.addAttribute("triviaAns", trivia.getAns());
		model.addAttribute("choices", trivia.getChoices());
		return "home";
	}
	
	@RequestMapping("/")
	public String sign_in() {
		return "sign_in";
	}
	
	@PostMapping("/sign_in")
	public String sign_in(@RequestParam("username") String username, @RequestParam("password") String password) {
		System.out.println("\n\n\nLogin processing\n\n\n");
		String statement = "SELECT * FROM login where id = ? and pswd = SHA2('database', ?)";
		Object [] pass = new Object[] {username, password};
		List<Map<String, Object>> mapList = jdbcTemplate.queryForList(statement, pass);
		if (mapList.size() != 0)
			return "home";
		else
			return "sign_in";
	}
	
	@GetMapping("/search")
	public String search(@RequestParam("category") String category, @RequestParam("key") String key, Model model) {
		String query = "select ";
		String prepStatement = "";
		if (category.equals("movieName")) {
			// search movie title
			prepStatement = "SELECT m_id, m_name, release_date, budget, revenue, runtime FROM movie where m_name = ?";
			List<Map<String, Object>> resultSet = jdbcTemplate.queryForList(prepStatement, key);
			if (resultSet.size() == 0)
				return "home";
			
			// A map of lists of actors
			TreeMap<String, List<Map<String, Object>>> actorResultSetMap = new TreeMap<String, List<Map<String, Object>>>();
			for (int i = 0; i < resultSet.size(); ++i) {
				String movieId = resultSet.get(i).get("m_id").toString();
				prepStatement = "select p_name, character_name from (select p_id, character_name from actor where m_id = ?) as t1 natural join person";
				List<Map<String, Object>> temp = jdbcTemplate.queryForList(prepStatement, movieId);
				actorResultSetMap.put(movieId, temp);
			}

			// A map of lists of genres
			TreeMap<String, List<Map<String, Object>>> genreResultSetMap = new TreeMap<String, List<Map<String, Object>>>();
			for (int i = 0; i < resultSet.size(); ++i) {
				String movieId = resultSet.get(i).get("m_id").toString();
				prepStatement = "select g_name, m_id from (genre natural join genre_to_movie) where m_id = ?";
				List<Map<String, Object>> temp = jdbcTemplate.queryForList(prepStatement, movieId);
				genreResultSetMap.put(movieId, temp);
			}
			
			// A map of lists of directors
			TreeMap<String, List<Map<String, Object>>> directorResultSetMap = new TreeMap<String, List<Map<String, Object>>>();
			for (int i = 0; i < resultSet.size(); ++i) {
				String movieId = resultSet.get(i).get("m_id").toString();
				prepStatement = "select p_name, m_id from person join (select d_id, m_id from movie where m_id = ?) as t1 on(d_id = p_id)";
				List<Map<String, Object>> temp = jdbcTemplate.queryForList(prepStatement, movieId);
				directorResultSetMap.put(movieId, temp);
			}
			
			model.addAttribute("resultSet", resultSet);
			model.addAttribute("actorRSM", actorResultSetMap);
			model.addAttribute("genreRSM", genreResultSetMap);
			model.addAttribute("dirRSM", directorResultSetMap);
			
			return "movie";
		} else if (category.equals("actorName") && key != null) {
			prepStatement = "SELECT p_id, p_name, gender, birthday, deathday FROM person where p_name = ?";
			List<Map<String, Object>> resultSet = jdbcTemplate.queryForList(prepStatement, "\"" + key +"\"");
			if (resultSet.size() == 0)
				return "home";
			
			TreeMap<String, List<Map<String, Object>>> characterResultSetMap = new TreeMap<String, List<Map<String, Object>>>();
			for (int i = 0; i < resultSet.size(); ++i) {
				String pid = resultSet.get(i).get("p_id").toString();
				prepStatement = "select m_name, character_name from (select m_id, p_id, character_name from actor where p_id = ?) as t1 join movie using (m_id)";
				List<Map<String, Object>> temp = jdbcTemplate.queryForList(prepStatement, pid);
				characterResultSetMap.put(pid, temp);
			}
			model.addAttribute("resultSet", resultSet);
			model.addAttribute("charRSM", characterResultSetMap);
			return "actor";
		} else if (category.equals("dirName") && key != null) {
			prepStatement = "SELECT p_id, p_name, gender, birthday, deathday FROM person where p_name = ?";
			List<Map<String, Object>> resultSet = jdbcTemplate.queryForList(prepStatement, "\"" + key +"\"");
			if (resultSet.size() == 0)
				return "home";
			
			TreeMap<String, List<Map<String, Object>>> directorResultSetMap = new TreeMap<String, List<Map<String, Object>>>();
			for (int i = 0; i < resultSet.size(); ++i) {
				String pid = resultSet.get(i).get("p_id").toString();
				prepStatement = "select m_name from person join movie on (d_id = p_id) where p_id = ?";
				List<Map<String, Object>> temp = jdbcTemplate.queryForList(prepStatement, pid);
				directorResultSetMap.put(pid, temp);
			}
			model.addAttribute("resultSet", resultSet);
			model.addAttribute("dirRSM", directorResultSetMap);
			return "director";
		} else if (category.equals("genre") && key != null) {
			prepStatement = "SELECT m_name from movie natural join genre_to_movie natural join genre where g_name = ?";
			List<Map<String, Object>> resultSet = jdbcTemplate.queryForList(prepStatement, key);
			if (resultSet.size() == 0)
				return "home";
			//TreeMap<String, List<Map<String, Object>>> genreResultSetMap = new TreeMap<String, List<Map<String, Object>>>();
			model.addAttribute("resultSet", resultSet);
			//model.addAttribute("genreRSM", genreResultSetMap);
			return "genre";
		} else if (category.equals("prodComp") && key != null) {
			prepStatement = "SELECT c_name,origin_country,m_name from movie natural join production_company_to_movie natural join production_companies where c_name = ?";
			List<Map<String, Object>> resultSet = jdbcTemplate.queryForList(prepStatement, key);
			if (resultSet.size() == 0)
				return "home";
			//TreeMap<String, List<Map<String, Object>>> prodResultSetMap = new TreeMap<String, List<Map<String, Object>>>();
			model.addAttribute("resultSet", resultSet);
			//model.addAttribute("genreRSM", genreResultSetMap);
			return "production";
		} else {
			//query += "* from movie";
		}
		return "home";
	}
	
}