package com.example.demo;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class TriviaMaster {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private String question;
	private String query;
	private String[] choices = new String[4];
	private Map<String, Object> row;
	private String ans;
	
	private String[] bases = {
			"Which of the following movies is %s in?",				//0. actor
			"Which of the following actors is in the movie %s?",	//1. movie
			"In what year did %s come out?",						//2. movie
			"Who directed %s?",										//3. movie
			"%s directed which of the following movies?", 			//4. director
			"What character did %s play in %s?",					//5. actor, movie
			"%s played what character in the %s %s movie?"};		//6. actor, year, genre
	

	@Autowired
	public TriviaMaster(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		int i = (int)(Math.random() * bases.length);
		buildQuery(i);
		row = jdbcTemplate.queryForList(query).get(0);
		makeQuestion(i);
	}

	public void buildQuery(int i) {
		query = "select ";
		if (i == 0 || i == 1 || i == 5) {
			query += "p_name, m_name, character_name from person natural join actor natural join movie ";
		} else if (i == 2) {
			query += "m_name, release_date from movie ";
		} else if (i == 3 || i == 4) {
			query += "m_name, p_name from movie join person on(d_id = p_id) ";
		} else {
			query += "p_name, character_name, release_date, g_name from person natural join actor natural join movie natural join genre_to_movie natural join genre ";
		}
		query += "order by rand() limit 1 ";
	}

	public void makeQuestion(int i) {
		String actor, movie, director, year, genre;
		switch (i) {
			case 0: //actor
				actor = row.get("p_name").toString().replaceAll("\"", "");
				question = String.format(bases[i], actor);
				ans = row.get("m_name").toString();
				break;
			case 1: //movie
				movie = row.get("m_name").toString();
				question = String.format(bases[i], movie);
				ans = row.get("p_name").toString();
				break;
			case 2: //movie
				movie = row.get("m_name").toString();
				question = String.format(bases[i], movie);
				ans = row.get("release_date").toString();
				ans = ans.substring(0, ans.indexOf('-'));
				break;
			case 3: //movie
				movie = row.get("m_name").toString();
				question = String.format(bases[i], movie);
				ans = row.get("p_name").toString();
				break;
			case 4: //director
				director = row.get("p_name").toString().replaceAll("\"", "");
				question = String.format(bases[i], director);
				ans = row.get("m_name").toString();
				break;
			case 5: //actor, movie
				actor = row.get("p_name").toString().replaceAll("\"", "");
				movie = row.get("m_name").toString();
				question = String.format(bases[i], actor, movie);
				ans = row.get("character_name").toString();
				break;
			case 6:	//actor, year, genre 
				actor = row.get("p_name").toString().replaceAll("\"", "");
				year = row.get("release_date").toString();
				year = year.substring(0, year.indexOf('-'));
				genre = row.get("g_name").toString();
				question = String.format(bases[i], actor, year, genre);
				ans = row.get("character_name").toString();
				break;
			default:
				break;
		}
		addChoice(ans);
	}
	
	public String getQ() {
		return question;
	}
	
	public String getQuery() {
		return query;
	}
	
	public String getAns() {
		return ans;
	}
	
	public String[] getChoices() {
		return choices;
	}
	
	public void addChoice(String c) {
		while (true) {
			int i = (int)(Math.random() * 4);
			if (choices[i] == null) {
				choices [i] = c;
				break;
			}
		}
	}
	
}